#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 14:12:55 2023

@author: abhishek
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 22:43:10 2023

@author: abhishekh
"""

def read_fasta(file_path: str):

    """
        Reads a FASTA file at the given `file_path` and concatenates the sequences into a single string.

        Parameters:
            file_path (str): The path to the FASTA file.

        Returns:
            str: Concatenated DNA sequence from the FASTA file.
    """

    from Bio import SeqIO
    sequence = ""
    
    for record in SeqIO.parse(file_path, "fasta"):
        sequence = sequence + str(record.seq)

    return sequence.upper()

def chaos_game_representation_key(kmer_length:int):

    """
    Generates the key matrix for Chaos Game Representation (CGR) for the given k-mer length.

    Parameters:
        kmer_length (int): The length of the k-mer.

    Returns:
        np.ndarray: A 2D numpy array representing the key matrix for CGR.
    """
    
    import numpy as np
    import sys
    
    if isinstance(kmer_length, int)==False:    
        sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
    if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
            
    row = col = np.power(2,kmer_length)
    
    arr = np.empty((row, col), dtype=object)
    arr.fill('')

    #     A = np.array([1, 0])
    # G = np.array([0, 0])
    # T = np.array([0, 1])
    # C = np.array([1, 1])
    
    arr[0:(row//2), 0:(col//2)] = "T"
    arr[0:(row//2), (col//2):col] = "C"
    arr[(row//2):row, 0:(col//2)] = "G"
    arr[(row//2):row, (col//2):col] = "A"
    
    bth = arr.copy()
    
    for i in range(kmer_length-1):
        
        bth = bth.reshape(row,row//2,2).transpose(2, 0, 1).reshape((row, col))
        arr = np.array([ y + x for x, y in zip(arr.flatten(), bth.flatten())]).reshape(arr.shape)
        
    return arr


def return_kmer_index(kmer: str):

    """
    Returns the index of a specific k-mer in the Chaos Game Representation (CGR) key matrix.

    Parameters:
        kmer (str): The k-mer for which the index is to be found.

    Returns:
        tuple: The row and column indices of the k-mer in the CGR key matrix.
    """

    import numpy as np
    import sys

    kmer_length = len(kmer)
    
    kmer = kmer.upper()
    
    if isinstance(kmer_length, int)==False:    
        sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
        
    if kmer_length<1:    
        sys.exit("The k-mer length cannot be less than 1.")
        
    if len(set(list(kmer)))>4:
        sys.exit("The kmer has more than 4 unique value. Present model works only for 4 unique character.")
        
    if not (set(list(set(list(kmer)))).issubset(['G', 'T', 'A', 'C'])):
        sys.exit("The kmer has charcater other than A, T, G, C. So we are exiting.")
        
    if kmer_length!=len(kmer):    
        sys.exit("The length of kmer and the query length mismatch. Both should be of same length.")
        
    
    chaos_game_kmer_array =  chaos_game_representation_key(kmer_length = kmer_length)

    indices = np.where(chaos_game_kmer_array == kmer)
    index_of_string = (indices[0][0], indices[1][0])

    # print("The index kmer {a} with kmer size {c} is {b}.".format(a= kmer, b = index_of_string, c = kmer_length))

    return index_of_string

def return_kmer_at_index(kmer_length:int, tuple_index : tuple):

    """
    Returns the k-mer at the specified index in the Chaos Game Representation (CGR) key matrix.

    Parameters:
        kmer_length (int): The length of the k-mer used to generate the Chaos Game Representation matrix.
        tuple_index (tuple): The index (row, column) of the k-mer in the matrix.

    Returns:
        str: The k-mer at the specified index.
    """


    import sys
    import numpy as np
    
    if tuple_index[0]> np.power(2, kmer_length) or tuple_index[1]> np.power(2, kmer_length):
        sys.exit("The row/ column index is out of the fcgr matrix.")

    chaos_game_kmer_array =  chaos_game_representation_key(kmer_length = kmer_length)
    print("The kmer at index {a} with kmer size {c} is {b}.".format(a= tuple_index, b = chaos_game_kmer_array[tuple_index], c = kmer_length))
    return chaos_game_kmer_array[tuple_index]



import numpy as np

def chaos_frequency_matrix(fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None,  pseudo_count = True):




    """
    Generates the chaos frequency matrix for the given DNA sequence.

    This function calculates the Chaos Frequency Matrix (CFM) for a given DNA sequence and k-mer length,
    using the Chaos Game Representation (CGR) key matrix.

    Parameters:
        fasta_string (str): The DNA sequence in FASTA format.
        kmer_length (int): The length of the k-mers to consider.
        chaos_game_kmer_array (np.array, optional): The Chaos Game Representation (CGR) key matrix. Defaults to None.
        pseudo_count (bool, optional): Whether to apply pseudo-counts to the matrix. Defaults to True.

    Returns:
        tuple: A tuple containing:
            - np.array: The chaos frequency matrix representing k-mer frequencies.
            - np.array: The Chaos Game Representation (CGR) key matrix used.
    """

    import numpy as np
    import sys
    import pandas as pd

    if isinstance(kmer_length, int)==False:    
        sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")

    if kmer_length<1:    
        sys.exit("The k-mer length cannot be less than 1.")
    if isinstance(fasta_string, str)==False:
        sys.exit("The fasta string contain non string value. It should contain only string.")

    fasta_string = fasta_string.upper()
    fasta_string = replace_non_atgc(fasta_string)

    if chaos_game_kmer_array is None:
        chaos_game_kmer_array = chaos_game_representation_key(kmer_length)

    rows = np.power(2, kmer_length)
    fcgr_sequence = return_kmer_count(fasta_string, kmer_length=kmer_length)
    fcgr_sequence_lookup = {k.upper(): v for k, v in fcgr_sequence.items()}
    matrix2 = np.zeros((rows, rows))

    for (i, j), value in np.ndenumerate(chaos_game_kmer_array):
        upper_value = value.upper()
        if upper_value in fcgr_sequence_lookup:
            matrix2[i, j] = fcgr_sequence_lookup[upper_value]

    if pseudo_count==True:
        matrix2 = (matrix2 + np.ones((matrix2.shape[0],matrix2.shape[1])))

    return matrix2, chaos_game_kmer_array

def chaos_frequency_dictionary(fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None, pseudo_count = True):


    """
    Calculate the frequency dictionary of k-mers in a chaos game representation matrix.

    Parameters:
        - fasta_string (str): The input DNA sequence in FASTA format.
        - kmer_length (int): The length of k-mers.
        - chaos_game_kmer_array (np.array): Chaos game k-mer array if pre-calculated, otherwise None.
        - pseudo_count (bool): Whether to apply pseudo-count (Laplace smoothing) or not. Default is True.

    Returns:
        - frequency_dictionary (dict): A dictionary containing k-mers as keys and their frequencies as values.
        
    """

    import pandas as pd
    
    
    import numpy as np
    import sys
    import pandas as pd

    if isinstance(kmer_length, int)==False:    
        sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")

    if kmer_length<1:    
        sys.exit("The k-mer length cannot be less than 1.")
    if isinstance(fasta_string, str)==False:
        sys.exit("The fasta string contain non string value. It should contain only string.")
        
    if chaos_game_kmer_array is None:
        chaos_game_kmer_array = chaos_game_representation_key(kmer_length)


    matrix2 = chaos_frequency_matrix(fasta_string= fasta_string, kmer_length=kmer_length, chaos_game_kmer_array=chaos_game_kmer_array, pseudo_count = pseudo_count)[0]

    df = pd.DataFrame(columns = ["kmer", "Freq"])
    df["kmer"] = chaos_game_kmer_array.ravel()
    df["Freq"] = matrix2.ravel()

    frequency_dictionary = {key: value for key, value in zip(df['kmer'], df['Freq'])}

    return frequency_dictionary


def return_kmer_count_individual(key_name: str, fasta_content: str):


    """
    Calculate the count of a specific k-mer in a given DNA sequence.

    Parameters:
        - key_name (str): The k-mer sequence for which the count is to be calculated.
        - fasta_content (str): The input DNA sequence in which the k-mer count is to be calculated.

    Returns:
        - count (int): The count of the specified k-mer in the DNA sequence.
    """

    kmer_length = len(key_name)
    count = 0
    
    for i in range(len(fasta_content)- kmer_length + 1):
        
        if (fasta_content[i: i + kmer_length]==key_name):
            count = count + 1
            
    return count



"""Below functions are for internal use only"""

def return_kmer_count(sequence:str, kmer_length:int):

    """
    Calculate the count of all k-mers of a specified length in a given DNA sequence.

    Parameters:
        - sequence (str): The input DNA sequence.
        - kmer_length (int): The length of k-mers to calculate the count for.

    Returns:
        - kmer_counts (dict): A dictionary containing all k-mers of the specified length
                              as keys and their counts in the DNA sequence as values.
    """

    from collections import defaultdict
    kmer_counts = defaultdict(int)  
    for i in range(len(sequence) - kmer_length + 1):
        kmer = sequence[i:i + kmer_length]
        kmer_counts[kmer] += 1
    return dict(kmer_counts)


def replace_non_atgc(sequence):

    """
    Replace non-ATGC characters in a DNA sequence with 'N'.

    Parameters:
        - sequence (str): The input DNA sequence.

    Returns:
        - result (str): The DNA sequence with non-ATGC characters replaced with 'N'.
    """
    result = ''.join(char if char in ['A', 'T', 'G', 'C', 'N'] else 'N' for char in sequence)
    
    return result


    
   
        
    
    
